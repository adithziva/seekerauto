[[cyan2]]
  
          888888    8888   88888
          88   88  88  88  88  88 
          888888   888888  88   88
          88   88  88  88  88  88 
          888888   88  88  88888     
   888888           
   88  88  8888888  888888   8888888
   888888  88   88  88   88  88   88
   8888    88   88  888888   88   88
   88 88   88   88  88   88  88   88
   88  88  8888888  888888   8888888 [[reset]]  
[[white2]]
-------------------------------------------------------  [[reset]]

[[cyan2]][1][[reset]] [[white2]]FollowBot -1  [[reset]]     [[cyan2]][6][[reset]] [[white2]]DM-Messenger [[reset]] 
             
[[cyan2]][2][[reset]] [[white2]]FollowBot -2 [[reset]]      [[cyan2]][7][[reset]] [[white2]]Unfollow Non-Followers [[reset]]

[[cyan2]][3][[reset]] [[white2]]Masslooker [[reset]]        [[cyan2]][8][[reset]] [[white2]]Profile-Scraper  [[reset]] 
              
[[cyan2]][4][[reset]] [[white2]]Re-Hashtag [[reset]]        [[cyan2]][9][[reset]] [[white2]]Rules [[reset]] 
              
[[cyan2]][5][[reset]] [[white2]]FeedLiker  [[reset]]        [[red]][10][[reset]] [[white2]]Exit [[reset]]
    
[[white2]]------------------------------------------------------- [[reset]]